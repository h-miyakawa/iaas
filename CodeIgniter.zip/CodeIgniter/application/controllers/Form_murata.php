<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Form_murata extends CI_Controller {
  var $userdata;
  var $action;
  public $test=1;
  public $users_filepath = '/home/ensyuu2/git/iaas/lib/users.json';
  public $listening_port = 44444;
  public $sending_port = 55555;
  public $controller_ip_address = '127.0.0.1';

  function Form_murata()
  {
    // 親コントローラクラスのコンストラクタを呼び出す
    parent::__construct();
    // ヘルパーを使えるようにしておく
    $this->load->helper('form');
    $this->load->helper('file');
    $this->load->helper('array');
    // ライブラリを使えるようにしておく
    $this->load->library('form_validation'); 
    $this->load->library('session');
     //バリデーション設定
    $this->form_validation->set_rules('name', 'ユーザID', 'required');
    $this->form_validation->set_rules('password', 'パスワード', 'required|alpha|min_length[4]');

    //エラーメッセージの基本形設定
    $this->form_validation->set_message('required', '%sが不適切。');
    
  }
  
  function index()
  {
    $this->test=2;
    
    //ランダムなチケットを生成し、セッションに保存します。
    $this->ticket = md5(uniqid(mt_rand(), TRUE));
    $this->session->set_userdata('ticket', $this->ticket);
    
    //step1のフォームを表示する
    $this->load->view('form_step1_murata');
    //バリデーション(検証)クラスのrun()メソッドを呼び出し、送信されたデータの検証
  }

  function checkLogin()
  {
     $userdata['user_id'] = $this->input->post('name');
     $userdata['password'] = $this->input->post('password');
     
     //セッション関連のメソッド
     $this->ticket = $this->session->userdata('ticket');
     
     //バリデーションクラスのrun()メソッドによる呼び出し
     if ($this->form_validation->run() == FALSE)
     {
        $this->load->view('form_step1_murata');
     }
     else
     {
        //登録されたユーザーかどうかの判定
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);

        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );
        
        if ($this->checkUser_Password($array,$userdata)){
            $userdata['action'] = "user_update";
            $this->send($userdata);
            //ACKが返ってくるまで待機?
            $this->receive();
            
            //ログイン成功。アクション選択画面へ移る
            $show_array = $this->get_user_status($userdata['user_id'],"vms");
            $userdata['current_status'] = $show_array;
            $userdata['vm_count'] = count($show_array);
            $show_array = $this->get_user_status($userdata['user_id'],"fw_rule");
            $userdata['current_status_fw'] = $show_array;
            $userdata['fw_count'] = count($show_array);
            $userdata['vm_status'] = $this->load->view('form_show_vm_status_change',$userdata,TRUE);
            $userdata['fw_status'] = $this->load->view('form_show_fw_status',$userdata,TRUE);
            
            $this->load->view('form_check_action',$userdata);
        }
        else{
            $this->load->view('form_step1_murata');
        }
     }
  }
  
  function continue_login(){
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    
    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive();
    
    $show_array = $this->get_user_status($userdata['user_id'],"vms");
    $userdata['current_status'] = $show_array;
    $userdata['vm_count'] = count($show_array);
    $show_array = $this->get_user_status($userdata['user_id'],"fw_rule");
    $userdata['current_status_fw'] = $show_array;
    $userdata['fw_count'] = count($show_array);
    $userdata['vm_status'] = $this->load->view('form_show_vm_status',$userdata,TRUE);
    $userdata['fw_status'] = $this->load->view('form_show_fw_status',$userdata,TRUE);
    
    $this->load->view('form_check_action',$userdata);
  }

  function checkAction()
  {        
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    
    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive();   
    
    $show_array = $this->get_user_status($userdata['user_id'],"vms");
    $userdata['current_status'] = $show_array;
    $userdata['vm_count'] = count($show_array);
    $show_array = $this->get_user_status($userdata['user_id'],"fw_rule");
    $userdata['current_status_fw'] = $show_array;
    $userdata['fw_count'] = count($show_array);
    $userdata['vm_status'] = $this->load->view('form_show_vm_status',$userdata,TRUE);
    $userdata['fw_status'] = $this->load->view('form_show_fw_status',$userdata,TRUE);
    $userdata['action'] = $this->input->post('action');
    
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    $this->form_validation->set_rules('action', 'アクション', 'required');
    
    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run()== FALSE)
    {
        //初回読み込み、またはエラー時のview呼び出し
        $this->load->view('form_check_action',$userdata);
    }
    else if ($userdata['action'] === 'user_delete'){
        $this->load->view('form_user_delete',$userdata);
    }
    else if ($userdata['action'] === 'vm_create'){
        $this->load->view('form_vm_create',$userdata);
    }
    else if ($userdata['action'] === 'vm_modify'){
        $this->load->view('form_vm_modify',$userdata);
    }
    else if ($userdata['action'] === 'vm_delete'){
        $this->load->view('form_vm_delete',$userdata);
    }
    else if ($userdata['action'] === 'vm_state_change'){
        $userdata['vm_state_change'] = $this->load->view('form_show_vm_status_change',$userdata,TRUE);
        $this->load->view('form_state_change',$userdata);
    }
    else if ($userdata['action'] === 'fw_control_add'){
        $this->load->view('form_fw_control_add',$userdata);
    }
    else if ($userdata['action'] === 'fw_control_modify'){
        $this->load->view('form_fw_control_modify',$userdata);
    }
    else if ($userdata['action'] === 'fw_control_delete'){
        $this->load->view('form_fw_control_delete',$userdata);
    }
  }
  
  function user_create()
  {
    
     //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    $this->form_validation->set_rules('passwordconf', 'パスワードの確認', 'required|matches[password]');
   
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    $userdata['passwordconf'] = $this->input->post('passwordconf');
    $userdata['action'] = "user_create";
    
    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
        //初回読み込み、またはエラー時のview呼び出し
        $this->load->view('form_user_create',$userdata);
    }
    else
    {   
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);
        
        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );

	//echo $array['users'][0]['user_id'];        

        //User判定
        if ($this->checkuseralready($array,$userdata))
        {
          //UserIDの追加を行う
          $addarray = array('user_id'=> $userdata['user_id'],'password'=>$userdata['password']);
          if ($array['users']===null){
            $array['users'][0] = $addarray;
          }
          else
          {
            $array['users'][count($array['users'])] = $addarray;
          }
	  //echo $array['users'][0]['password'];

          //JSONにエンコード
          $json = json_encode( $array , JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ;
          write_file($this->users_filepath,$json);
          //コントローラへのメッセージ送信
          $this->send($userdata);
          $this->load->view('suceed',$userdata);
        }
        else
        {
          //すでにUserIDがあったため、アクションを拒否
          echo "もうID使われてました。。。";
        }
        
        /*
        //コントローラへメッセージの送信
        $this->send($userdata);
        //コントローラからメッセージの受信
        $receive_message = $this->receive();
        if (strstr($receive_message,"YES")){
          $this->load->view('suceed');
        }
        else{
          echo "だめでした。。。";
        }
         //createのview呼び出し
        */
        
    }
  }
  
  function user_delete()
  {
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    $userdata['action'] = $this->input->post('action');
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    
    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive(); 
    
    $show_array = $this->get_user_status($userdata['user_id'],"vms");
    $userdata['current_status'] = $show_array;
    $userdata['vm_count'] = count($show_array);
    $show_array = $this->get_user_status($userdata['user_id'],"fw_rule");
    $userdata['current_status_fw'] = $show_array;
    $userdata['fw_count'] = count($show_array);
    $userdata['vm_status'] = $this->load->view('form_show_vm_status',$userdata,TRUE);
    $userdata['fw_status'] = $this->load->view('form_show_fw_status',$userdata,TRUE);
    $userdata['action'] = $this->input->post('action');
    
    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
        //初回読み込み、またはエラー時のview呼び出し
        $this->load->view('form_user_delete',$userdata);
    }
    else
    {        
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);
        
        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );
        
        if ($this->checkUser_Password($array,$userdata))
        {
            //該当UserIDの探索
            $counter = 0;
            foreach ($array['users'] as $value){
              if (element('user_id',$value) === $userdata['user_id']){
                  break;
              }
              $counter++;
            }
            
            //ユーザーが作っているVMが起動していないかチェック
            if ($this->check_VM_standby($array,$userdata,$counter)){
                //すべてが停止している→ユーザーの削除ができる
                //UserIDの削除を行う
                array_splice($array['users'],$counter,1);
                //JSONにエンコード
                $json = json_encode( $array , JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ;
                write_file($this->users_filepath,$json);
                //コントローラへのメッセージ送信
                $this->send($userdata);
                //終了ビューの表示
                $this->load->view('suceed',$userdata);
            }
            else {
                //停止できていないVMがあるので、それを停止するように促す。
                $this->load->view('fail_to_delete_user',$userdata);
            }
        }
    }
  }
  
  function vm_control()
  {
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    //バリデーション設定
    $this->form_validation->set_rules('vm_id', 'VMのID', 'required');
    $this->form_validation->set_rules('cpu', 'CPUの数', 'required|is_natural_no_zero');
    $this->form_validation->set_rules('memory', 'メモリ容量', 'required|is_natural_no_zero');
    $this->form_validation->set_rules('volume', 'ディスク容量', 'required|is_natural_no_zero');
    
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    $userdata['vm_id'] = $this->input->post('vm_id');
    $userdata['cpu'] = $this->input->post('cpu');
    $userdata['memory'] = $this->input->post('memory');
    $userdata['volume'] = $this->input->post('volume');
    
    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive();   
    
    $show_array = $this->get_user_status($userdata['user_id'],"vms");
    $userdata['current_status'] = $show_array;
    $userdata['vm_count'] = count($show_array);
    $userdata['vm_status'] = $this->load->view('form_show_vm_status',$userdata,TRUE);
    $userdata['action'] = $this->input->post('action');

    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
        switch ($userdata['action']) {
          case "vm_create":
            //初回読み込み、またはエラー時のview呼び出し
            $this->load->view('form_vm_create',$userdata);
            break;
          case "vm_modify":
            //初回読み込み、またはエラー時のview呼び出し
            $this->load->view('form_vm_modify',$userdata);
            break;
        }
    }
    else
    {
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);
        
        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );
        
        if ($this->checkUser_Password($array,$userdata))
        {
            switch($userdata['action']){
                case "vm_create":
                    //何もしない
                    break;
                case "vm_modify":
                    //そのVMが起動しているかチェック
                    if ($this->get_VM_status($array,$userdata) === "standby"){
                        break;
                    }
                    else{
                        //runnning or processing だったため、VMの編集ができない
                        $this->load->view('fail_to_modify_vm',$userdata);
                    }
                break;
            }
            //コントローラへのメッセージ送信
            $this->send($userdata);
            //コントローラからのACK受信 (JSONで送られてくる)
            $receive_message = $this->receive();
            //JSONのデコード
            $receive_array = json_decode( $receive_message , true );
            if ($receive_array['field']['status'] === "OK")
            {
                //VM_CREATEの成功
                //終了ビューの表示
               $this->load->view('suceed',$userdata);
            }
            else
            {
                 switch ($userdata['action']) {
                    case "vm_create":
                        //VMが作られなかった
                        echo "VM生成できませんでした。";
                        echo "VMのID：".$receive_array['field']['vm_id'];
                        echo "原因：".$receive_array['field']['message'];
                        break;
                    case "vm_modify":
                        //VMが編集できなかった
                        echo "VM編集できませんでした。";
                        echo "VMのID：".$receive_array['field']['vm_id'];
                        echo "原因：".$receive_array['field']['message'];
                        break;
                }
            }
        }
    }
  }
  
  function vm_delete()
  {
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    //バリデーション設定
    $this->form_validation->set_rules('vm_id', 'VMのID', 'required');

    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    $userdata['vm_id'] = $this->input->post('vm_id');
    
    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive();      
    
    $show_array = $this->get_user_status($userdata['user_id'],"vms");
    $userdata['current_status'] = $show_array;
    $userdata['vm_count'] = count($show_array);
    $userdata['vm_status'] = $this->load->view('form_show_vm_status',$userdata,TRUE);
    $userdata['action'] = $this->input->post('action');
    

    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
        //初回読み込み、またはエラー時のview呼び出し
        $this->load->view('form_vm_delete',$userdata);
    }
    else
    {
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);
        
        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );
        
        if ($this->checkUser_Password($array,$userdata))
        {
            //そのVMが起動しているかチェック
            if ($this->get_VM_status($array,$userdata) === "standby"){
                //コントローラへのメッセージ送信
                $this->send($userdata);
                //コントローラからのACK受信 (JSONで送られてくる)
                $receive_message = $this->receive();
                //JSONのデコード
                $receive_array = json_decode( $receive_message , true );
                if ($receive_array['field']['status'] === "OK"){
                    //VM_CREATEの成功
                    //終了ビューの表示
                    $this->load->view('suceed',$userdata);
                }
                else
                {
                    echo "無理でした。。。。。";
                }
            }
            else{
                //runnning or processing だったため、VMの編集ができない
                $this->load->view('fail_to_delete_vm',$userdata);
            }
        }
    }
  }
  
  function state_change()
  {
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    $userdata['action'] = $this->input->post('action');
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    $userdata['vm_state'] = $this->input->post('status');
    $userdata['vm_id_change'] = $this->input->post('vm_id_change');

     //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
        //ここに突入する可能性はゼロなので何もしない
    }
    else
    {
        $this->send($userdata); //VM_START or VM_STOPのメッセージの送信
        
        //ファイルの更新
        $userdata['action'] = "user_update";
        $this->send($userdata);
        //ACKが返ってくるまで待機?
        $this->receive();     
        
        //アクションをもとに戻す
        $userdata['action'] = $this->input->post('action');
        
        //ビューの表示
        $show_array = $this->get_user_status($userdata['user_id'],"vms");
        $userdata['current_status'] = $show_array;
        $userdata['vm_count'] = count($show_array);
        $userdata['vm_state_change'] = $this->load->view('form_show_vm_status_change',$userdata,TRUE);
        $this->load->view('form_state_change',$userdata);
    }   
    
  }
  
  function fw_control()
  {
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    //バリデーション設定
    $this->form_validation->set_rules('rule_no', 'ルール番号', 'required|is_natural_no_zero|less_than[1000]');
    $this->form_validation->set_rules('filter', 'フィルタリング', 'required');
    $this->form_validation->set_rules('source_ip_address', '許可/拒否する送信元 IP アドレス', 'valid_ip');
    $this->form_validation->set_rules('destination_ip_address', '許可/拒否する宛先 IP アドレス', 'valid_ip');
    $this->form_validation->set_rules('destination_tcp_port', '許可/拒否する宛先 TCP ポート番号', 'is_natural_no_zero');
    
    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    $userdata['rule_no'] = $this->input->post('rule_no');
    $userdata['filter'] = $this->input->post('filter');
    $userdata['source_ip_address'] = $this->input->post('source_ip_address');
    $userdata['destination_ip_address'] = $this->input->post('destination_ip_address');
    $userdata['destination_tcp_port'] = $this->input->post('destination_tcp_port');

    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive();          
    
    $show_array = $this->get_user_status($userdata['user_id'],"fw_rule");
    $userdata['current_status_fw'] = $show_array;
    $userdata['fw_count'] = count($show_array);
    $userdata['fw_status'] = $this->load->view('form_show_fw_status',$userdata,TRUE);
    $userdata['action'] = $this->input->post('action');
    
    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
        switch ($userdata['action']) {
          case "fw_control_add":
            //初回読み込み、またはエラー時のview呼び出し
            $this->load->view('form_fw_control_add',$userdata);
            break;
          case "fw_control_modify":
            //初回読み込み、またはエラー時のview呼び出し
            $this->load->view('form_fw_control_modify',$userdata);
            break;
        }
    }
    else
    {
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);
        
        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );
        
        if ($this->checkUser_Password($array,$userdata))
        {
            //コントローラへのメッセージ送信
            $this->send($userdata);
            //コントローラからのACK受信 (JSONで送られてくる)
            $receive_message = $this->receive();
            //JSONのデコード
            $receive_array = json_decode( $receive_message , true );
            if ($receive_array['field']['status'] === "OK")
            {
                //VM_CREATEの成功
                //終了ビューの表示
               $this->load->view('suceed',$userdata);
            }
            else
            {
                echo "無理でした。。。。。";
            }
        }
    }
  }
  
  function fw_control_delete(){
    //セッション関連のメソッド
    $this->ticket = $this->session->userdata('ticket');
    
    //バリデーション設定
    $this->form_validation->set_rules('rule_no', 'ルール番号', 'required|is_natural_no_zero|');
    

    $userdata['user_id'] = $this->input->post('name');
    $userdata['password'] = $this->input->post('password');
    $userdata['rule_no'] = $this->input->post('rule_no');
    
    $userdata['action'] = "user_update";
    $this->send($userdata);
    //ACKが返ってくるまで待機?
    $this->receive();          
    
    $show_array = $this->get_user_status($userdata['user_id'],"fw_rule");
    $userdata['current_status_fw'] = $show_array;
    $userdata['fw_count'] = count($show_array);
    $userdata['fw_status'] = $this->load->view('form_show_fw_status',$userdata,TRUE);
    $userdata['action'] = $this->input->post('action');

    //バリデーションクラスのrun()メソッドによる呼び出し.
    if ($this->form_validation->run() == FALSE)
    {
         //初回読み込み、またはエラー時のview呼び出し
        $this->load->view('fw_control_delete',$userdata);
    }
    else
    {
        //json_dataファイルの読み込み
        $json = read_file($this->users_filepath);
        
        //JSONを連想配列に配列型で変換(デコード)
        $array = json_decode( $json , true );
        
        if ($this->checkUser_Password($array,$userdata))
        {
            //コントローラへのメッセージ送信
            $this->send($userdata);
            //コントローラからのACK受信 (JSONで送られてくる)
            $receive_message = $this->receive();
            //JSONのデコード
            $receive_array = json_decode( $receive_message , true );
            if ($receive_array['field']['status'] === "OK")
            {
                //VM_CREATEの成功
                //終了ビューの表示
               $this->load->view('suceed',$userdata);
            }
            else
            {
                echo "無理でした。。。。。";
            }
        }   
    }    
  }
  
  function checkUser_Password($array,$userdata)
  {
        //User判定
        if ($this->checkuseralready($array,$userdata))
        {
          //checkuseralreadyはユーザー名がないときにtrue,あるときにfalseを返す
          
          //そんなUserIDはないため、アクションを拒否
          echo "そんなIDは登録されてません。よってできません。";
          return false;
        }
        else
        {
          //該当UserIDの探索
          $counter = 0;
          foreach ($array['users'] as $value){
            if (element('user_id',$value) === $userdata['user_id']){
                break;
            }
            $counter++;
          }
          //当該ユーザーと登録されているパスワードと現在入力したパスワードが正しいか
          if ($array['users'][$counter]['password'] === $userdata['password'])
          {
            return true;
          }
          else
          {
            //false:パスワードが不一致
            echo "パスワードがユーザーIDに一致しません。よってできません";
            return false;
          }
        }
  }
  
  function check_VM_standby($array,$userdata,$counter){
    if(array_key_exists('vms', $array['users'][$counter])){
        foreach ($array['users'][$counter]['vms'] as $value){
            if ($value['status'] === "runnig"){
                return false;
            }
            else if ($value['status'] === "processing"){
                return false;
            }
            else{
            //standbyだったからok
            //何もしない
            }
        }
        //foreachを抜けることができると、すべてのVMはstandbyになっている
        return true;
    }
    else{
        //vmは一つもないのでユーザー削除できる
        return true;
    }
  }
  
  function get_VM_status($array,$userdata){
    foreach ($array['users'] as $line){
        if ($line['user_id'] === $userdata['user_id']){
            if (array_key_exists('vms',$line)){
                foreach ($line['vms'] as $value){
                    if ($value['vm_id'] === $userdata['vm_id']){
                        return $value['status'];
                    }
                }
            }
        }
    }
    return null;
  }
  
  function checkuseralready($array,$userdata)
  {        
    if ($array === null)
    {
        //新しいユーザ名だった。
        return true;
    }
    else 
    {
      foreach ($array['users'] as $value){
        if (element('user_id', $value) === $userdata['user_id'])
        {
          //すでにそのユーザ名は登録されていた
          return false;
        }
      }
    }
    return true;
  }  
  
  
  function send($userdata)
  {
    $sock = fsockopen($this->controller_ip_address, $this->sending_port, $errono, $errmsg, 30 );
    $upperaction =  strtoupper($userdata['action']);
    switch($userdata['action']){
        case "user_update":
            $fieldarray = array('user_id'=>$userdata['user_id']);   
            break;
        case "user_create":
            $fieldarray = array('user_id'=>$userdata['user_id']);        
            break;
        case "user_delete":
            $fieldarray = array('user_id'=>$userdata['user_id']);
            break;
        case "vm_create":
            $fieldarray = array('user_id'=>$userdata['user_id'],'vm_id'=>$userdata['vm_id'],'cpu'=>$userdata['cpu'],'memory'=>$userdata['memory'],'volume'=>$userdata['volume']);           
            break;
        case "vm_modify":
            $fieldarray = array('user_id'=>$userdata['user_id'],'vm_id'=>$userdata['vm_id'],'cpu'=>$userdata['cpu'],'memory'=>$userdata['memory'],'volume'=>$userdata['volume']);           
            break;
        case "vm_delete":
            $fieldarray = array('user_id'=>$userdata['user_id'],'vm_id'=>$userdata['vm_id']);
            break;
        case "vm_start":
            $fieldarray = array('user_id'=>$userdata['user_id'],'vm_id'=>$userdata['vm_id_change']);
            break;
        case "vm_stop":
            $fieldarray = array('user_id'=>$userdata['user_id'],'vm_id'=>$userdata['vm_id_change']);
            break;            
        case "fw_control_add":
            //下のarrayは、メッセージに応じて変更する
            $fieldarray = array('user_id'=>$userdata['user_id'],'rule_no'=>$userdata['rule_no'],'filter'=>$userdata['filter'],'source_ip_address'=>$userdata['source_ip_address'],'destination_ip_address'=>$userdata['destination_ip_address'],'destination_tcp_port'=>$userdata['destination_tcp_port']);
            break;
        case "fw_control_modify":
            $fieldarray = array('user_id'=>$userdata['user_id'],'rule_no'=>$userdata['rule_no'],'filter'=>$userdata['filter'],'source_ip_address'=>$userdata['source_ip_address'],'destination_ip_address'=>$userdata['destination_ip_address'],'destination_tcp_port'=>$userdata['destination_tcp_port']);
            break;
        case "fw_control_delete":
            $fieldarray = array('user_id'=>$userdata['user_id'],'rule_no'=>$userdata['rule_no']);
            break;
    }
    $sendarray = array('function'=>$upperaction,'field'=>$fieldarray );
    //コントローラへ送るJSONメッセージの作成
    $str = json_encode( $sendarray , JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ;
    //データ送信
    fputs($sock, $str);
  }
      
  function receive()
  {
    $sock = socket_create_listen($this->listening_port);
    $clientsock = socket_accept($sock);
    $buf = socket_read($clientsock, 1024);
    if (strlen($buf)>0)
    {
      return $buf;
    }
    socket_close($clientsock);
    socket_close($sock);
  }
  
  function get_user_status($username,$flag)
  {
    //ページにユーザの利用状況を表示するために、そのユーザーのJSONデータにvmsががあるかどうかを返すメソッド
    
    //json_dataファイルの読み込み
    $json = read_file($this->users_filepath);
    
    //JSONを連想配列に配列型で変換(デコード)
    $array = json_decode( $json , true );
    
/*
    //テスト用データ(vm)
    $array['users'][2]['vms'][0]['vm_id']="vm01";
    $array['users'][2]['vms'][0]['cpu']=2;
    $array['users'][2]['vms'][0]['memory']=10;
    $array['users'][2]['vms'][0]['volume']=100;
    $array['users'][2]['vms'][0]['status']="running";
    
    //テスト用データ(fw)
    $array['users'][2]['fw_rule'][0]['rule_no']="1";
    $array['users'][2]['fw_rule'][0]['filter']="allow";
    $array['users'][2]['fw_rule'][0]['source_ip_address']="192.168.255.50";
    $array['users'][2]['fw_rule'][0]['destination_ip_address']="192.168.255.50";
    $array['users'][2]['fw_rule'][0]['destination_tcp_port']="50";
    $array['users'][2]['fw_rule'][0]['destination_udp_port']="100";
*/
 
    foreach ($array['users'] as $value){
        if (element('user_id', $value) === $username)
        {
            switch($flag){
                case "vms":
                    //そこにvmsのキーが存在するか
                    if(array_key_exists('vms', $value)){
                        //vmは存在する。
                        return $value['vms'];
                    }
                    else
                    {
                        return null;
                    }
                    break;
                case "fw_rule":
                    //そこにvmsのキーが存在するか
                    if(array_key_exists('fw_rule', $value)){
                        //vmは存在する。
                        return $value['fw_rule'];
                    }
                    else
                    {
                        return null;
                    }                    
                    break;
            }
        }
    }
  }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
