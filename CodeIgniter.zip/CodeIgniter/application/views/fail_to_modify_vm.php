<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
  <title>Thank you</title>
</head>
<body>
  <h1>指定したVMは停止していないので、編集することができません。もしくは指定したVMは存在していません。</h1>
  <h2>VNの変更・削除等の場合は以下をクリック</h2>  
    <div class="action_select_form">
    <?php echo validation_errors(); ?>
    <?php echo form_open('form_murata/continue_login'); ?>
    <?php echo form_hidden('ticket',$this->ticket);?>
    <?php echo form_hidden('name',"$user_id");?>
    <?php echo form_hidden('password',"$password"); ?>
        <p class="ログイン"><input type="submit" value="アクション選択に戻る"/></p>
    </form>
    </div>
    <a href="http://192.168.1.2/CodeIgniter/form_murata/">ログインページ</a><br>
</body>
</html>