<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>Form Step1</title>

</head>

<body>
    <div  id="main">
    <div class="action_select_form">
    <h1>アクション選択</h1>
    <?php echo validation_errors(); ?>
    <?php echo form_open('form_murata/checkAction'); ?>
    <?php echo form_hidden('ticket',$this->ticket);?>
        <fieldset>
            <p class="attention">*は必須項目です</p>
            <table>
                <tbody>
                    <tr>
                        <th>アクション</th>
                        <td>
                            <select id="action" name="action">
                                    <option value="">---</option>
                                    <option value="user_delete">user_delete</option>
                                    <option value="vm_create">vm_create</option>
                                    <option value="vm_modify">vm_modify</option>
                                    <option value="vm_delete">vm_delete</option>
                                    <option value="vm_state_change">vm_state_change</option>
                                    <option value="fw_control_add">fw_control_add</option>
                                    <option value="fw_control_modify">fw_control_modify</option>
                                    <option value="fw_control_delete">fw_control_delete</option>
                            </select>
                        </td>
                    </tr>
                    <?php echo form_hidden('name',"$user_id");?>
                    <?php echo form_hidden('password',"$password"); ?>
                </tbody>
            </table>
            <p class="ログイン"><input type="submit" value="submit"/></p>
        </fieldset>
    </form>
    </div>
    <div class="show_vm_status"><?=$vm_status?></div>
    <div class="show_fm_status"><?=$fw_status?></div>
    </div>
</body>
</html>
