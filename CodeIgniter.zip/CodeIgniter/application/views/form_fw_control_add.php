<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>Form Step2</title>

</head>

<body>
    <div id="main">
    <div class="fw_add_form">
    <h1>ファイアーウォールのルール追加</h1>
    <?php echo validation_errors(); ?>
    <?php echo form_open('form_murata/fw_control'); ?>
    <?php echo form_hidden('ticket',$this->ticket);?>
        <fieldset>
            <p class="attention">*は必須項目です</p>
            <table>
                <tbody>
                     <tr>
                        <th>ルール番号<span>*</span></th>
                        <td><input type="text" id="rule_no" name="rule_no" value="" /></td>
                    </tr>
                    <tr>
                        <th>フィルタリング(許可または拒否)</th>
                        <td>
                            <select id="filter" name="filter">
                                    <option value="">---</option>
                                    <option value="allow">allow</option>
                                    <option value="deny">deny</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>許可/拒否する送信元 IP アドレス,指定無しで全部<span>*</span></th>
                        <td><input type="text" id="source_ip_address" name="source_ip_address" value="" /></td>
                    </tr>
                    <tr>
                        <th>許可/拒否する宛先 IP アドレス,指定無しで全部<span>*</span></th>
                        <td><input type="text" id="destination_ip_address" name="destination_ip_address" value="" /></td>
                    </tr>
                    <tr>
                        <th>許可/拒否する宛先 TCP ポート番号<span>*</span></th>
                        <td><input type="text" id="destination_tcp_port" name="destination_tcp_port" value="" /></td>
                    </tr>
                    <?php echo form_hidden('name',"$user_id");?>
                    <?php echo form_hidden('action',"$action"); ?>
                    <?php echo form_hidden('password',"$password");?>
                </tbody>
            </table>
            <p class="submit"><input type="submit" value="submit"/></p>
        </fieldset>
    </form>
    </div>
    <div class="show_fw_status"><?=$fw_status?></div>
    </div>
</body>
</html>