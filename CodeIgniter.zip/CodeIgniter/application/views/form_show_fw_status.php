<?php if ($fw_count>0):?>
<div align="center">
<table width="100%" border="1" cellspacing="0">
<tbody>
<h3>ユーザID : <?=$user_id?>が設定したファイアーウォール一覧</h3>
<tr>
<th bgcolor="#E8DF8E" class="line_2">&nbsp;</th>
<th bgcolor="#E8DF8E" class="line_1">ルール番号</th>
<th bgcolor="#E8DF8E" class="line_1">許可または拒否,allow または deny</th>
<th bgcolor="#E8DF8E" class="line_1">許可/拒否する送信元 IP アドレス,指定無しで全部</th>
<th bgcolor="#E8DF8E" class="line_1">許可/拒否する宛先 IP アドレス,指定無しで全部</th>
<th bgcolor="#E8DF8E" class="line_1">許可/拒否する宛先 TCP ポート番号</th>
</tr>

<?php foreach($current_status_fw as $line => $item): ?>
<tr>
<td width="30" align="center" bgcolor="#E1E1E1" class="line_2"><?= $line+1?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['rule_no']?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['filter']?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['source_ip_address']?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?= $item['destination_ip_address']?></td>
<?php if(array_key_exists('destination_tcp_port',$item)):?>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['destination_tcp_port']?></td>
<?php else:?>
<td align="center" bgcolor="#FFFFFF" class="line_1">未設定</td>
<?php endif;?>
</tr>
<?php endforeach; ?>

</tbody>
</table>
</div>

<?php else: ?>
<div align="center">
<table width="100%" border="1" cellspacing="0">
<tbody>
<h3>ユーザID : <?=$user_id?>が設定したファイアーウォール一覧</h3>
<tr>
<th bgcolor="#E8DF8E" class="line_2">&nbsp;</th>
<th bgcolor="#E8DF8E" class="line_1">ルール番号</th>
<th bgcolor="#E8DF8E" class="line_1">許可または拒否,allow または deny</th>
<th bgcolor="#E8DF8E" class="line_1">許可/拒否する送信元 IP アドレス,指定無しで全部</th>
<th bgcolor="#E8DF8E" class="line_1">許可/拒否する宛先 IP アドレス,指定無しで全部</th>
<th bgcolor="#E8DF8E" class="line_1">許可/拒否する宛先 TCP ポート番号</th>
</tr>
<?php endif; ?>