<?php if ($vm_count>0):?>
<div align="center">
<table width="80%" border="1" cellspacing="0">
<tbody>
<h3>ユーザID : <?=$user_id?>が設定したVM一覧</h3>
<tr>
<th bgcolor="#E8DF8E" class="line_2">&nbsp;</th>
<th bgcolor="#E8DF8E" class="line_1">VM_ID</th>
<th bgcolor="#E8DF8E" class="line_1">IPアドレス</th>
<th bgcolor="#E8DF8E" class="line_1">CPUの数</th>
<th bgcolor="#E8DF8E" class="line_1">メモリ容量</th>
<th bgcolor="#E8DF8E" class="line_1">ディスク容量</th>
<th bgcolor="#E8DF8E" class="line_1">状態</ht>
</tr>

<?php foreach($current_status as $line => $item): ?>
<tr>
<td width="30" align="center" bgcolor="#E1E1E1" class="line_2"><?= $line+1?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['vm_id']?></td>
<?php if(array_key_exists('ip_address',$item)):?>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['ip_address']?></td>
<?php else:?>
<td align="center" bgcolor="#FFFFFF" class="line_1">未設定</td>
<?php endif;?>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?= $item['cpu']?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?=$item['memory']?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1"><?= $item['volume']?></td>
<td align="center" bgcolor="#FFFFFF" class="line_1">
<?=form_open('form_murata/state_change');?>
<?php echo form_hidden('name',"$user_id");?>
<?php echo form_hidden('password',"$password"); ?>
<input type="hidden" name="vm_id_change" value="<?=$item['vm_id']?>" />
<?php if($item['status'] === "running"):?>
<?php echo form_hidden('action',"vm_stop");?>
起動中
<input type="submit" value="停止する"/>
<?php elseif($item['status'] === "processing"):?>
セットアップ中
<?php else:?>
<?php echo form_hidden('action',"vm_start");?>
停止中
<input type="submit" value="起動する"/>
<?php endif;?>
<?=form_close();?>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?=form_open('form_murata/continue_login');?>
<?php echo form_hidden('name',"$user_id");?>
<?php echo form_hidden('action',"$action"); ?>
<?php echo form_hidden('password',"$password"); ?>
<p class="更新"><input type="submit" value="更新ボタン"/></p>
<?=form_close();?>
</div>

<?php else: ?>
<div align="center">
<table width="80%" border="1" cellspacing="0">
<tbody>
<h3>ユーザID : <?=$user_id?>が設定したVM一覧</h3>
<tr>
<th bgcolor="#E8DF8E" class="line_2">&nbsp;</th>
<th bgcolor="#E8DF8E" class="line_1">VM_ID</th>
<th bgcolor="#E8DF8E" class="line_1">IPアドレス</th>
<th bgcolor="#E8DF8E" class="line_1">CPUの数</th>
<th bgcolor="#E8DF8E" class="line_1">メモリ容量</th>
<th bgcolor="#E8DF8E" class="line_1">ディスク容量</th>
<th bgcolor="#E8DF8E" class="line_1">状態</ht>
</tr>
</tbody>
</table>
<?=form_open('form_murata/continue_login');?>
<?php echo form_hidden('name',"$user_id");?>
<?php echo form_hidden('action',"$action"); ?>
<?php echo form_hidden('password',"$password"); ?>
<p class="更新"><input type="submit" value="更新ボタン"/></p>
<?=form_close();?>
</div>
<?php endif; ?>
