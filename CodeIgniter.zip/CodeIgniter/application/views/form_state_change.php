<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>Form Step2</title>

</head>

<body>
 <h1>VM状態更新</h1>
    <div id ="main">
        <div class="show_vm_state_change"><?=$vm_state_change?></div>    
    </div>
</body>
</html>