<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>Form Step1</title>

</head>

<body>

    <h1>ログイン画面</h1>
    
    <?php echo validation_errors(); ?>
    <?php echo form_open('form_murata/checkLogin'); ?>
    <?php echo form_hidden('ticket',$this->ticket);?>
        <fieldset>
            <p class="attention">*は必須項目です</p>
            <table>
                <tbody>
                    <tr>
                        <th>User ID (Slice Name)<span>*</span></th>
                        <td><input type="text" id="name" name="name" value="" /></td>
                    </tr>
                    <tr>
                        <th>パスワード<span>*</span></th>
                        <td><input type="password" id="password" name="password" value="" /></td>
                    </tr>
                </tbody>
            </table>
        </fieldset>
        <p class="ログイン"><input type="submit" value="login"/></p>
    </form>
    <h2>ユーザID新規登録の場合は以下のURLをクリック</h2>  
    <a href="http://localhost/CodeIgniter/form_murata/user_create/">新規登録</a><br>
</body>
</html>