<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>Form UserCreate</title>

</head>

<body>

    <h1>UserCreate</h1>
    <?php echo validation_errors(); ?>
    <?php echo form_open('form_murata/user_create'); ?>
    <?php echo form_hidden('ticket',$this->ticket);?>
        <fieldset>
            <p class="attention">*は必須項目です</p>
            <table>
                <tbody>
                    <tr>
                        <th>User ID (Slice Name)<span>*</span></th>
                        <td><input type="text" id="name" name="name" value="" /></td>
                    </tr>
                    <tr>
                        <th>パスワード<span>*</span></th>
                        <td><input type="password" id="password" name="password" value="" /></td>
                    </tr>
                    <tr>
                        <th>パスワードの確認<span>*</span></th>
                        <td><input type="password" id="passwordconf" name="passwordconf" value="" /></td>
                    </tr>
                </tbody>
            </table>
        </fieldset>
        <p class="submit"><input type="submit" value="submit"/></p>
    </form>

</body>
</html>