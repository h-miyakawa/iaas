<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>Form Step2</title>

</head>

<body>
    <div id="main">
    <div class = "vm_create_form">
    <h1>VM_Modify</h1>
    <?php echo validation_errors(); ?>
    <?php echo form_open('form_murata/vm_control'); ?>
    <?php echo form_hidden('ticket',$this->ticket);?>
        <fieldset>
            <p class="attention">*は必須項目です</p>
            <table>
                <tbody>
                    <tr>
                        <th>VMのID<span>*</span></th>
                        <td><input type="text" id="vm_id" name="vm_id" value="" /></td>
                    </tr>
                    <tr>
                        <th>CPUの数<span>*</span></th>
                        <td><input type="text" id="cpu" name="cpu" value="" /></td>
                    </tr>
                    <tr>
                        <th>メモリ容量[MB]<span>*</span></th>
                        <td><input type="text" id="memory" name="memory" value="" /></td>
                    </tr>
                    <tr>
                        <th>ディスク容量[GB]<span>*</span></th>
                        <td><input type="text" id="volume" name="volume" value="" /></td>
                    </tr>
                    <?php echo form_hidden('name',"$user_id");?>
                    <?php echo form_hidden('action',"$action"); ?>
                    <?php echo form_hidden('password',"$password"); ?>
                </tbody>
            </table>
            <p class="submit"><input type="submit" value="submit"/></p>
        </fieldset>
    </form>
    </div>
    <div class="show_vm_status"><?=$vm_status?></div>
    </div>
    </body>
</html>